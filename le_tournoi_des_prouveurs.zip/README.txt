# Le tournoi des prouveurs

Version collaborative à 6 joueurs.

## Utilisation
1. Mets `index.html` sur un hébergement web statique.
2. Le premier joueur crée une salle.
3. Il envoie le code à ses frères sur Messenger.
4. Les 5 autres rejoignent avec ce code.
5. Chacun renseigne 3 jeux et valide.
6. Quand les 6 sont prêts, l'organisateur lance le tirage.

La connexion entre les joueurs utilise PeerJS via son serveur de signalisation public. Les données de la partie restent dans les navigateurs pendant la partie ; il n'y a pas de compte ni de base de données.

Pour une utilisation réelle, le site doit être servi en HTTPS (un hébergement statique moderne le fait automatiquement).
